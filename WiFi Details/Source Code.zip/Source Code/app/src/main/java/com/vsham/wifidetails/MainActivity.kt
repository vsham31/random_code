package com.vsham.wifidetails

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.text.format.Formatter
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Invoking the Wifi Manager
        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        // Method to get the current connection info
        val wInfo = wifiManager.connectionInfo

        // Extracting the information from the received connection info
        val ipAddress = Formatter.formatIpAddress(wInfo.ipAddress)
        val linkSpeed = wInfo.linkSpeed
        val networkID = wInfo.networkId
        val ssid = wInfo.ssid
        val hssid = wInfo.hiddenSSID
        val bssid = wInfo.bssid

        val wifiInformationTv = findViewById<TextView>(R.id.wifiInfo)

        // Setting the text inside the textView with
        // various entities of the connection
        wifiInformationTv.text =

            "IP Address:\t$ipAddress\n" +
                    "Link Speed:\t$linkSpeed\n" +
                    "Network ID:\t$networkID\n" +
                    "SSID:\t$ssid\n" +
                    "Hidden SSID:\t$hssid\n" +
                    "BSSID:\t$bssid\n"


/*
        // Finding the textView from the layout file
        val ipdisp = findViewById<TextView>(R.id.ipAddress)
        val linkdisp = findViewById<TextView>(R.id.linkSpeed)
        val netidisp = findViewById<TextView>(R.id.networkID)
//        val ipdisp = findViewById<TextView>(R.id.ipAddress)
//        val ipdisp = findViewById<TextView>(R.id.ipAddress)



        // Setting the text inside the textView with
        // various entities of the connection
        ipdisp.text = "IP Address:\t$ipAddress\n"
        linkdisp.text="Link Speed:\t$linkSpeed\n"
        netidisp.text="Network ID:\t$networkID\n"
            "SSID:\t$ssid\n" +
            "Hidden SSID:\t$hssid\n" +
            "BSSID:\t$bssid\n"
*/    }


}